# Amrit Dalmia — Resume Website

**Student:** Amrit Dalmia  
**Roll number:** 26120162  
**College:** Indian Institute of Management Bangalore  
**Email:** amritdalmia096@gmail.com

## Files
- `index.html` — website content and navigation
- `style.css` — layout, typography, colors, cards and responsive styling

## Before publishing
1. Replace the LinkedIn placeholder with your personal profile URL if you want to display it.
2. Review the coursework examples and keep only projects you have actually completed.
3. Add your expected graduation year and any other verified resume details.

## Preview locally
Double-click `index.html` to open it in a browser. Keep `style.css` in the same folder.

## Publish with GitHub Pages
1. Sign in to https://github.com/ and create a new **public** repository named `amrit-resume`.
2. Upload `index.html` and `style.css` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. After publishing, copy the exact live URL and repository URL into the assignment PDF.

Typical live URL: `https://YOUR-USERNAME.github.io/amrit-resume/`
